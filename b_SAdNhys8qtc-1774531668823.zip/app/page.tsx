"use client"

import { useState } from "react"
import { NeuralBackground } from "@/components/neural-background"
import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { AboutSection } from "@/components/about-section"
import { ProjectsSection } from "@/components/projects-section"
import { EducationSection } from "@/components/education-section"
import { SkillsSection } from "@/components/skills-section"
import { ContactSection } from "@/components/contact-section"
import { ScrollProgress } from "@/components/scroll-progress"
import { BackToTop } from "@/components/back-to-top"
import { Footer } from "@/components/footer"

export default function Portfolio() {
  const [showNav, setShowNav] = useState(false)
  const [profileInNav, setProfileInNav] = useState(false)

  const handleScrollPast = (isPast: boolean) => {
    setShowNav(isPast)
    setProfileInNav(isPast)
  }

  return (
    <main className="relative min-h-screen">
      <NeuralBackground />
      <ScrollProgress />
      <Navbar showNav={showNav} profileInNav={profileInNav} />
      
      <HeroSection onScrollPast={handleScrollPast} />
      <AboutSection />
      <ProjectsSection />
      <EducationSection />
      <SkillsSection />
      <ContactSection />
      <Footer />
      
      <BackToTop />
    </main>
  )
}
