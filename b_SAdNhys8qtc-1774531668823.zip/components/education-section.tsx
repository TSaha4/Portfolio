"use client"

import { motion, useInView } from "framer-motion"
import { useRef } from "react"
import { GraduationCap, Calendar } from "lucide-react"

const education = [
  {
    degree: "Master of Science in Computer Science",
    school: "Stanford University",
    period: "2020 - 2022",
    description: "Specialized in Machine Learning and Distributed Systems. Graduated with honors.",
  },
  {
    degree: "Bachelor of Science in Software Engineering",
    school: "MIT",
    period: "2016 - 2020",
    description: "Focus on full-stack development and software architecture. Dean's List all semesters.",
  },
  {
    degree: "Full Stack Web Development Bootcamp",
    school: "Codecademy Pro",
    period: "2019",
    description: "Intensive 12-week program covering React, Node.js, and modern web technologies.",
  },
]

export function EducationSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="education" className="py-20 px-6" ref={ref}>
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            <span className="text-primary">Education</span>
          </h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-12 rounded-full" />
        </motion.div>

        {/* Vertical Timeline */}
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-6 md:left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary via-primary/50 to-primary/20" />

          <div className="space-y-8">
            {education.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -30 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="relative pl-16 md:pl-20"
              >
                {/* Timeline dot */}
                <div className="absolute left-6 md:left-8 top-6 -translate-x-1/2">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={isInView ? { scale: 1 } : {}}
                    transition={{ duration: 0.4, delay: index * 0.2 + 0.2 }}
                    className="w-4 h-4 rounded-full bg-primary shadow-lg shadow-primary/50 ring-4 ring-background"
                  />
                </div>

                {/* Content Card */}
                <motion.div
                  whileHover={{ x: 4 }}
                  transition={{ duration: 0.2 }}
                  className="bg-[var(--glass-bg)] backdrop-blur-xl border border-[var(--glass-border)] rounded-xl p-6 shadow-lg hover:shadow-xl hover:border-primary/30 transition-all duration-300"
                >
                  {/* Period badge */}
                  <div className="flex items-center gap-2 text-xs font-medium text-primary bg-primary/10 px-3 py-1 rounded-full w-fit mb-3">
                    <Calendar className="w-3 h-3" />
                    {item.period}
                  </div>

                  {/* Degree */}
                  <div className="flex items-start gap-3 mb-2">
                    <GraduationCap className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                    <h3 className="text-lg font-semibold text-foreground leading-tight">
                      {item.degree}
                    </h3>
                  </div>

                  {/* School */}
                  <p className="text-primary font-medium mb-3 ml-8">{item.school}</p>

                  {/* Description */}
                  <p className="text-muted-foreground text-sm ml-8">{item.description}</p>
                </motion.div>
              </motion.div>
            ))}
          </div>

          {/* Timeline end dot */}
          <motion.div
            initial={{ scale: 0 }}
            animate={isInView ? { scale: 1 } : {}}
            transition={{ duration: 0.4, delay: 0.8 }}
            className="absolute left-6 md:left-8 -bottom-2 -translate-x-1/2 w-2 h-2 rounded-full bg-primary/30"
          />
        </div>
      </div>
    </section>
  )
}
