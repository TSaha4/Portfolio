"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"
import { FileText } from "lucide-react"

export function AboutSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="about" className="py-20 px-6" ref={ref}>
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            About <span className="text-primary">Me</span>
          </h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-12 rounded-full" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="bg-[var(--glass-bg)] backdrop-blur-xl border border-[var(--glass-border)] rounded-2xl p-8 md:p-12 shadow-lg"
        >
          <p className="text-lg text-muted-foreground leading-relaxed mb-6">
            Hello! I&apos;m Alex, a passionate full-stack developer with over 5 years of experience 
            building modern web applications. I specialize in creating elegant, user-centric 
            digital experiences that combine beautiful design with robust functionality.
          </p>
          <p className="text-lg text-muted-foreground leading-relaxed mb-6">
            My journey in tech started when I built my first website at 15, and since then, 
            I&apos;ve been captivated by the endless possibilities of web development. I love 
            tackling complex problems and turning ideas into reality through clean, 
            efficient code.
          </p>
          <p className="text-lg text-muted-foreground leading-relaxed mb-8">
            When I&apos;m not coding, you&apos;ll find me exploring new technologies, contributing 
            to open-source projects, or enjoying a good cup of coffee while reading about 
            the latest trends in UI/UX design.
          </p>

          <motion.a
            href="/resume.pdf"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-full font-medium hover:opacity-90 transition-opacity shadow-lg shadow-primary/25"
          >
            <FileText className="w-5 h-5" />
            Download Resume
          </motion.a>
        </motion.div>
      </div>
    </section>
  )
}
