"use client"

import { motion, useInView } from "framer-motion"
import { useRef, useState } from "react"
import { Mail, MapPin, Phone, Send, Github, Linkedin } from "lucide-react"

// X (Twitter) icon component
function XIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  )
}

const contactInfo = [
  {
    icon: Mail,
    label: "Email",
    value: "alex@example.com",
    href: "mailto:alex@example.com",
  },
  {
    icon: MapPin,
    label: "Location",
    value: "San Francisco, CA",
    href: null,
  },
  {
    icon: Phone,
    label: "Phone",
    value: "+1 (555) 123-4567",
    href: "tel:+15551234567",
  },
]

const socialLinks = [
  { 
    icon: Github, 
    href: "https://github.com", 
    label: "GitHub",
    hoverBg: "hover:bg-[#333] dark:hover:bg-[#f0f0f0]",
    hoverText: "hover:text-white dark:hover:text-[#333]"
  },
  { 
    icon: Linkedin, 
    href: "https://linkedin.com", 
    label: "LinkedIn",
    hoverBg: "hover:bg-[#0A66C2]",
    hoverText: "hover:text-white"
  },
  { 
    icon: XIcon, 
    href: "https://x.com", 
    label: "X",
    hoverBg: "hover:bg-[#000] dark:hover:bg-[#fff]",
    hoverText: "hover:text-white dark:hover:text-black"
  },
]

export function ContactSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null)

  return (
    <section id="contact" className="py-20 px-6" ref={ref}>
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            Get In <span className="text-primary">Touch</span>
          </h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-4 rounded-full" />
          <p className="text-center text-muted-foreground mb-12 max-w-lg mx-auto">
            Have a project in mind or want to collaborate? Feel free to reach out!
          </p>
        </motion.div>

        {/* Contact Cards */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid md:grid-cols-3 gap-6 mb-12"
        >
          {contactInfo.map((item, index) => (
            <motion.div
              key={item.label}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.1 * index }}
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
              onTouchStart={() => setHoveredIndex(index)}
              onTouchEnd={() => setTimeout(() => setHoveredIndex(null), 300)}
              className="group"
            >
              {item.href ? (
                <a href={item.href} className="block">
                  <ContactCard item={item} isHovered={hoveredIndex === index} />
                </a>
              ) : (
                <ContactCard item={item} isHovered={hoveredIndex === index} />
              )}
            </motion.div>
          ))}
        </motion.div>

        {/* Social Links */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="flex justify-center gap-4"
        >
          {socialLinks.map((social) => (
            <motion.a
              key={social.label}
              href={social.href}
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              className={`p-4 rounded-full bg-[var(--glass-bg)] backdrop-blur-xl border border-[var(--glass-border)] transition-all duration-300 shadow-lg hover:border-transparent ${social.hoverBg} ${social.hoverText}`}
              aria-label={social.label}
            >
              <social.icon className="w-6 h-6" />
            </motion.a>
          ))}
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-12 text-center"
        >
          <a
            href="mailto:alex@example.com"
            className="inline-flex items-center gap-2 px-8 py-4 bg-primary text-primary-foreground rounded-full font-medium hover:opacity-90 transition-all hover:scale-105 shadow-lg shadow-primary/25"
          >
            <Send className="w-5 h-5" />
            Send Me a Message
          </a>
        </motion.div>
      </div>
    </section>
  )
}

interface ContactCardProps {
  item: {
    icon: React.ComponentType<{ className?: string }>
    label: string
    value: string
  }
  isHovered: boolean
}

function ContactCard({ item, isHovered }: ContactCardProps) {
  return (
    <div
      className={`relative p-6 rounded-2xl bg-[var(--glass-bg)] backdrop-blur-xl border border-[var(--glass-border)] text-center transition-all duration-300 ${
        isHovered ? "shadow-2xl shadow-primary/20 -translate-y-1 border-primary/30" : "shadow-lg"
      }`}
    >
      {/* Glow effect */}
      <div
        className={`absolute inset-0 rounded-2xl bg-primary/5 transition-opacity duration-300 ${
          isHovered ? "opacity-100" : "opacity-0"
        }`}
      />
      
      <motion.div
        animate={isHovered ? { scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] } : {}}
        transition={{ duration: 0.4 }}
        className="relative inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary/10 mb-4"
      >
        <item.icon className="w-6 h-6 text-primary" />
      </motion.div>
      <h3 className="text-sm font-medium text-muted-foreground mb-1 relative">{item.label}</h3>
      <p className="text-foreground font-medium relative">{item.value}</p>
    </div>
  )
}
