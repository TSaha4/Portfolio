"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { useTheme } from "next-themes"
import { Menu, X, Sun, Moon } from "lucide-react"
import Image from "next/image"

const navLinks = [
  { name: "About", href: "#about" },
  { name: "Projects", href: "#projects" },
  { name: "Education", href: "#education" },
  { name: "Skills", href: "#skills" },
  { name: "Contact", href: "#contact" },
]

interface NavbarProps {
  showNav: boolean
  profileInNav: boolean
}

export function Navbar({ showNav, profileInNav }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const { setTheme, resolvedTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault()
    const element = document.querySelector(href)
    if (element) {
      const navHeight = 80
      const elementPosition = element.getBoundingClientRect().top + window.scrollY
      window.scrollTo({
        top: elementPosition - navHeight,
        behavior: "smooth",
      })
    }
    setMobileMenuOpen(false)
  }

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <>
      {/* Desktop Navbar Container */}
      <div className="fixed top-4 left-4 right-4 z-50 hidden md:block">
        <AnimatePresence mode="wait">
          {!showNav ? (
            // Standalone toggle when navbar is hidden - positioned to the right
            <motion.div
              key="standalone-toggle-container"
              className="flex justify-end"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <motion.button
                initial={{ scale: 0.8 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0.8 }}
                transition={{ duration: 0.2 }}
                onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
                className="p-3 rounded-full bg-[var(--glass-bg)] backdrop-blur-xl border border-[var(--glass-border)] shadow-lg hover:bg-primary/20 transition-colors"
                aria-label="Toggle theme"
              >
                {mounted && (resolvedTheme === "dark" ? (
                  <Sun className="w-5 h-5 text-primary" />
                ) : (
                  <Moon className="w-5 h-5 text-primary" />
                ))}
              </motion.button>
            </motion.div>
          ) : (
            // Full navbar - full width
            <motion.nav
              key="full-navbar"
              className="w-full rounded-2xl bg-[var(--glass-bg)] backdrop-blur-xl border border-[var(--glass-border)] shadow-lg overflow-hidden"
              initial={{ 
                opacity: 0,
                y: -20,
              }}
              animate={{ 
                opacity: 1,
                y: 0,
              }}
              exit={{ 
                opacity: 0,
                y: -20,
              }}
              transition={{ 
                duration: 0.3, 
                ease: [0.4, 0, 0.2, 1],
              }}
            >
              <div className="px-6 py-3 flex items-center justify-between">
                {/* Left: Profile + Name */}
                <motion.button 
                  onClick={scrollToTop}
                  className="flex items-center gap-3 hover:opacity-80 transition-opacity"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.15 }}
                >
                  <Image
                    src="/profile.jpg"
                    alt="Profile"
                    width={40}
                    height={40}
                    className="rounded-full object-cover border-2 border-primary"
                  />
                  <span className="text-lg font-semibold text-foreground whitespace-nowrap">
                    Alex Johnson
                  </span>
                </motion.button>

                {/* Center: Nav Links */}
                <div className="flex items-center gap-8 flex-1 justify-center">
                  {navLinks.map((link, index) => (
                    <motion.a
                      key={link.name}
                      href={link.href}
                      onClick={(e) => scrollToSection(e, link.href)}
                      className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors relative group whitespace-nowrap"
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: 0.1 + index * 0.05 }}
                    >
                      {link.name}
                      <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full" />
                    </motion.a>
                  ))}
                </div>

                {/* Right: Theme Toggle */}
                {mounted && (
                  <motion.button
                    onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
                    className="p-2 rounded-full bg-muted hover:bg-primary/20 transition-colors flex-shrink-0"
                    aria-label="Toggle theme"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.2, delay: 0.2 }}
                  >
                    {resolvedTheme === "dark" ? (
                      <Sun className="w-5 h-5 text-primary" />
                    ) : (
                      <Moon className="w-5 h-5 text-primary" />
                    )}
                  </motion.button>
                )}
              </div>
            </motion.nav>
          )}
        </AnimatePresence>
      </div>

      {/* Mobile Navbar - Always visible */}
      <header className="fixed top-0 left-0 right-0 z-50 md:hidden">
        <nav className="mx-3 mt-3 rounded-xl bg-[var(--glass-bg)] backdrop-blur-xl border border-[var(--glass-border)] shadow-lg">
          <div className="px-4 py-3 flex items-center justify-between">
            <button onClick={scrollToTop} className="flex items-center gap-2">
              <AnimatePresence>
                {profileInNav && (
                  <motion.div
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0, opacity: 0 }}
                    className="flex items-center gap-2"
                  >
                    <Image
                      src="/profile.jpg"
                      alt="Profile"
                      width={32}
                      height={32}
                      className="rounded-full object-cover border-2 border-primary"
                    />
                    <span className="text-sm font-semibold text-foreground">Alex</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </button>

            <div className="flex items-center gap-2">
              {mounted && (
                <button
                  onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
                  className="p-2 rounded-full bg-muted hover:bg-primary/20 transition-colors"
                  aria-label="Toggle theme"
                >
                  {resolvedTheme === "dark" ? (
                    <Sun className="w-4 h-4 text-primary" />
                  ) : (
                    <Moon className="w-4 h-4 text-primary" />
                  )}
                </button>
              )}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-full bg-muted hover:bg-primary/20 transition-colors"
                aria-label="Toggle menu"
              >
                {mobileMenuOpen ? (
                  <X className="w-5 h-5 text-foreground" />
                ) : (
                  <Menu className="w-5 h-5 text-foreground" />
                )}
              </button>
            </div>
          </div>
        </nav>
      </header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm md:hidden"
            onClick={() => setMobileMenuOpen(false)}
          >
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="absolute right-0 top-0 h-full w-64 bg-[var(--glass-bg)] backdrop-blur-xl border-l border-[var(--glass-border)] p-6 pt-20"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex flex-col gap-6">
                {navLinks.map((link, index) => (
                  <motion.a
                    key={link.name}
                    href={link.href}
                    onClick={(e) => scrollToSection(e, link.href)}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="text-lg font-medium text-foreground hover:text-primary transition-colors"
                  >
                    {link.name}
                  </motion.a>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
